package main

import (
    "fmt" //导入fmt包，调用其中的Println()函数
)

func main() {
    fmt.Println("Hello，world！")
}
